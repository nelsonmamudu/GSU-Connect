# GSU Connect — authentication & onboarding screenshots

41 screenshots of every reachable state in the sign-in, registration, password-recovery and account-status flows.

**Start here:** `00-overview-all.png` (contact sheet of everything), or the four section sheets:

| Sheet | Covers |
|---|---|
| `00-overview-sign-in.png` | Sign-in states, errors, dark mode, mobile |
| `00-overview-create-account.png` | Student, staff, graduate, file upload, validation, dark mode |
| `00-overview-recovery.png` | Forgot password, reset sent/error, set-new-password |
| `00-overview-status.png` | Pending, rejected, suspended, upload, edit, alumni, expired |

## How these were captured

The real components from this repo (`AuthScreen`, `SetPasswordScreen`, `StatusGateScreen`, and `App` for the account-lifecycle states) were rendered in a headless Chromium harness. Supabase was replaced with an in-memory mock so the flows are deterministic and no production data was touched. Fonts are the app's real DM Sans / Plus Jakarta Sans / JetBrains Mono.

Screens use the app's real copy, validation and layout at commit `b121a21`. Timestamps and names in the screenshots are sample data.

## Sign-in (`01`–`09`)

| File | State |
|---|---|
| `01-sign-in` | Default sign-in |
| `02-sign-in-submitting` | "Signing in…" button state |
| `03-sign-in-wrong-credentials` | Wrong matric/password error |
| `04-sign-in-invalid-identifier` | Malformed identifier error |
| `05-sign-in-email-not-confirmed` | Unconfirmed email error |
| `06-sign-in-rate-limited` | Client throttle / too-many-attempts error |
| `07-sign-in-network-error` | Offline / failed-to-fetch error |
| `08-sign-in-dark` | Dark theme |
| `09-sign-in-mobile` | 390 px mobile layout |

## Create account (`10`–`20`)

| File | State |
|---|---|
| `10-create-account` | Empty student registration |
| `11-create-account-student-filled` | Completed student form |
| `12-create-account-staff-filled` | Lecturer/staff form |
| `13-create-account-graduate-filled` | Graduate — Class of 2026 |
| `14-create-account-id-card-selected` | ID/proof file selected |
| `15-create-account-error-level` | Missing level |
| `16-create-account-error-department` | Missing department |
| `17-create-account-error-phone` | Invalid phone number |
| `18-create-account-duplicate-id` | Matric/Staff ID already registered |
| `19-create-account-submitting` | "Creating account…" button state |
| `20-create-account-dark` | Dark theme |

## Password recovery (`21`–`26`)

| File | State |
|---|---|
| `21-forgot-password` | Forgot-password form |
| `22-forgot-password-sent` | "Check your inbox" confirmation |
| `23-forgot-password-error` | Send failure |
| `24-set-new-password` | Reset-link destination |
| `25-set-new-password-mismatch` | Passwords do not match |
| `26-set-new-password-rejected` | Server rejects the new password |

## Account status (`27`–`41`)

| File | State |
|---|---|
| `27-pending-student` | "Waiting for Approval" |
| `28-pending-student-id-attached` | Pending with proof attached |
| `29-pending-student-edit-details` | Inline department/level editor |
| `30-pending-student-edit-recovery-email` | Inline recovery-email editor |
| `31-pending-student-upload-success` | Proof uploaded |
| `32-pending-student-upload-error` | Upload rejected |
| `33-pending-student-details-saved` | Details corrected |
| `34-pending-lecturer` | "Pending Admin Verification" |
| `35-rejected-account` | Rejected with reason |
| `36-suspended-account` | Suspended |
| `37-pending-student-dark` | Pending, dark theme |
| `38-rejected-account-dark` | Rejected, dark theme |
| `39-pending-student-mobile` | Pending, 390 px mobile |
| `40-alumni-verification-banner` | Signed in as an alumnus with the verification window open |
| `41-account-expired` | Alumni verification window closed — forced sign-out gate |

`40` and `41` are rendered by the real `App` shell; workspace cards are empty because the harness has no seeded chat/calendar data.

## Issues visible in the screenshots

1. **Graduate level is truncated** in the two-column signup grid (`Graduate — Class of 2…`) — `13`.
2. **Pending-lecturer copy is wrong**: the "What happens next" panel says a class rep or department helper will review a lecturer, but staff approvals are admin-only — `34`.
3. **Recovery-email editor is cramped**: the input truncates the address and the Save/Cancel buttons crowd it — `30`.
4. **The recovery-email row breaks the table rhythm**: a long address pushes the value onto its own line under the label, so “Edit details” floats on the label row and the value sits below it (unlike Level) — `27`.
